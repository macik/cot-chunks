Template chunks
============

Extension for Cotonti CMF. Extension for template system to use admin editable chunks

Description
-----------

More detailed description...

Features
--------

* feature1
* feature2

Demo page
---------

Sample page included in Extension pack. Just install `chunks` and open plugin page
( http://www.yoursite.com/index.php?e=chunks ).

Requirements
------------

Current version 1.0.0 requires Cotonti Siena v

### Compatibility

Some notes for compatibility with versions and themes.


### Comments

Plugin works out from the box. For better results 


### How extension works

How it works...


Install
-------

* Unpack, copy files to root folder of your site.
* Install via Admin → Extensions menu (`Administration panel → Extensions`)
* Checks setting in config (`Administration panel → Extensions → chunks → Configuration`).

### Comments

To see this Extension in action - open «chunks» plugin page. 

Licence
-------

Distributed under BSD license.


Author
------

[Andrey Matsovkin](https://github.com/macik/)

References
----------

* [Cotonti.com](http://Cotonti.com/) -- Home of Cotonti CMF
* [chunks on GitHub](https://github.com/macik/cot-chunks) -- Latest version of chunks on GitHub