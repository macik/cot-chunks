<?php
/**
 * Template chunks plugin API
 * @package Plugins/Chunks
 * @author Andrey Matsovkin
 * @copyright Copyright (c) 2011-2014
 * @license Distributed under BSD license.
 */

defined('COT_CODE') or die('Wrong URL');
// require_once cot_langfile('chunks', 'plug');

//global $db_chunks, $db_x;
//$db_contact = (isset($db_contact)) ? $db_contact : $db_x . 'contact';