<?php
/**
 * Static and dynamic resource (e.g. HTML) strings. Can be overriden by skin files and other code.
 * @package chunks
 * @author Andrey Matsovkin
 * @copyright Copyright (c) 2011-2014
 * @license Distributed under BSD license.
 * Made with «Extension Template» (https://github.com/macik/cot-extension_template)
 */
defined('COT_CODE') or die('Wrong URL');
require_once cot_langfile('chunks', 'plug');

//R['comments_code_admin'] = $L['Ip'].': {$ipsearch}<span class="spaced">'.$cfg['separator'].'</span><a href="{$delete_url}">'.$L['Delete'].'</a><span class="spaced">'.$cfg['separator'].'</span>';