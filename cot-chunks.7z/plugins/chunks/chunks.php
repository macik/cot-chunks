<?php
/* ====================
[BEGIN_COT_EXT]
Hooks=standalone
[END_COT_EXT]
==================== */

/**
 * Template chunks
 *
 * @package chunks
 * @author Andrey Matsovkin
 * @copyright Copyright (c) 2011-2014
 * @license Distributed under BSD license.
 * Made with «Extension Template» (https://github.com/macik/cot-extension_template)
 */

defined('COT_CODE') or die('Wrong URL.');
$plug_name = 'chunks';
$base_path = $cfg['plugins_dir']."/$plug_name";

//require cot_incfile('chunks', 'plug', 'common');
//$t = new XTemplate(cot_tplfile('chunks', 'plug'));
//$t = new XTemplate(cot_tplfile('chunks.edit', 'plug'));


$plugin_body .= 'Plugin installed (file chunks).<br/>';