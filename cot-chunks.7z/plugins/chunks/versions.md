Template chunks
============

Extension for Cotonti CMF. Extension for template system to use admin editable chunks


Changelog
---------


### v1.0.0 (2014-Sep-01)

* Basic features