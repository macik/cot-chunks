<?php
/**
 * Removes all implanted configs
 *
 * @package chunks
 * @author Andrey Matsovkin
 * @copyright Copyright (c) 2011-2014
 * @license Distributed under BSD license.
 */

defined('COT_CODE') or die('Wrong URL');
global $L;

/*
require_once cot_incfile('extrafields');
require_once cot_langfile('chunks', 'plug');
cot::$db->registerTable('users');

// deleting extrafield from pages
if (cot_extrafield_remove(cot::$db->users,'chunks_exf1'))
{
	cot_message('adm_extrafield_removed');
}
else
{
	cot_error('adm_extrafield_not_removed');
}
*/

//global $db, $db_config;
//$db->delete($db_config, "config_donor = 'chunks'");