/* Drops all plugin data completely */
-- DROP TABLE IF EXISTS `table`;