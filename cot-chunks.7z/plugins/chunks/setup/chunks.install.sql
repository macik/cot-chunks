/* Plugin schema */

-- Main comments table
-- CREATE TABLE IF NOT EXISTS `table` ();