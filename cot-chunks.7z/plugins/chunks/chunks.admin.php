<?php
/* ====================
Copyright (c) 2011-2014, Andrey Matsovkin
All rights reserved. Distributed under BSD license.

[BEGIN_COT_EXT]
Code=chunks
Part=admin
File=chunks.admin
Hooks=tools
Order=10
[END_COT_EXT]
Made with «Extension Template» (https://github.com/macik/cot-extension_template)
==================== */
(defined('COT_CODE') && defined('COT_ADMIN')) or die('Wrong URL.');
$plug_name = 'chunks';
$plugin_body .= 'Admin Part of chunks Plugin installed (file chunks.admin).<br/>';